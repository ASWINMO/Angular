import { Component } from '@angular/core';
import{FormBuilder,Validators}from '@angular/forms';
import { DataService } from '../services/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  un:string=""
  ps:string=""

  logform=this.fb.group({
    username:['',[Validators.required,Validators.pattern("[a-zA-Z0-9]+")]],
    password:['',[Validators.required,Validators.minLength(2)]]
  })

  constructor(private fb:FormBuilder,private r:Router,private ds:DataService){}

  log(){
    if(this.logform.valid){
      console.log(this.logform.value)
      this.ds.getToken(this.logform.value).then(r=>r.json())
      .then(data=>{
      if (data["token"]){
        localStorage.setItem("token", data["token"])
      }
      else{
        localStorage.setItem("token","null")
      }
    })
    if (localStorage.getItem("token")=="null"){
      alert("login failed")
    }
    else{
      this.r.navigate(["home"])
    }
  }
    // else{
    //   if(this.logform.get("uname")?.errors){
    //     alert("username invalid")
    //   }
    //   if(this.logform.get("pswd")?.errors){
    //     alert("password invalid")

    // }


  }
}
