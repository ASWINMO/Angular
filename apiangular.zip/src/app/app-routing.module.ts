import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { DishComponent } from './dish/dish.component';
import { ReviewComponent } from './review/review.component';

const routes: Routes = [
  {path:"reg",component:RegisterComponent},
  {path:"home",component:HomeComponent},
  {path:"dish/:id",component:DishComponent},
  {path:"review/:id",component:ReviewComponent},
  {path:"",component:LoginComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
