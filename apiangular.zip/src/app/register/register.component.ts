import { Component } from '@angular/core';
import{FormBuilder} from '@angular/forms'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent{



  regform=this.fb.group({
    uname:'',
    pswd:'',
    email:''
  })

  constructor(private fb:FormBuilder){}

  reg(){
    console.log(this.regform.value.uname)
    console.log(this.regform.value.pswd)
    console.log(this.regform.value.email)

  }

}
